function PlayerPiece() {
  return (
    <div className="player-piece">
      <div className="player-head"></div>
      <div className="player-body"></div>
    </div>
  )
}

export default PlayerPiece

  